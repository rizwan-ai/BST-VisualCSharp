﻿using System;
using static System.Console;
using static System.Convert;

namespace Recursive_BST_Operations
{
    class Program
    {
        static void Main(string[] args)
        {
            Title = "Recursive BST Operations";


            BST bst = new BST();

            Write("Enter Total (Nodes) Values : ");
            int length = ToInt32(ReadLine());
            for (int i = 0; i < length; i++)
            {
                Write($"Enter Value {i + 1} : ");
                int val = ToInt32(ReadLine());
                bst.InsertNode(val);
            }

            //Write("Enter value to search : ");
            //int v = ToInt32(ReadLine());
            //bst.SearchNode(v);

            WriteLine("InOrder Traversing");
            bst.InOrder();

            WriteLine("\nPreOder Traversing");
            bst.PreOrder();

            WriteLine("\nPostOrder Traversing");
            bst.PostOrder();

            ReadKey(true);
        }
    }
}
